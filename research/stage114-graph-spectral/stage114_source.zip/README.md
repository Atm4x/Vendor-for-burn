# Stage 114 — Graph-aware spectral ResBlock research

This is an offline research package. It does **not** modify NeuroMita, Burn or production RVC.

## Hypothesis and algebra

The known RTX 4060 experiment established that Stage112 fused two-tap deconvolution is slower than ILP4. For `GeneratorNSF` with `resblock=1`, the three ResBlock branches dominate the operation count. Stage114 studies changing the *operator representation* for these convolutions, not CTA tiling or GEMM-only implementations.

For one centered dilated PyTorch cross-correlation,

`y[t,o] = b[o] + sum_i sum_k W[o,i,k] * x[t + k*d - p,i]`, where `p=(K-1)*d/2`,

set a circular impulse `h[(p-k*d) mod N,o,i] = W[o,i,k]`. Use an `N`-point real FFT and one complex matrix multiplication per frequency. Overlap-save returns exactly `M=N-(K-1)*d` valid output samples per window; the valid local output segment is `[p:p+M]`. Zero-padding handles boundaries. The algorithm is mathematically identical in exact arithmetic, regardless of channel rank or convolution group.

As a graph-aware optimization, the first convolution of all three branches shares the same LeakyReLU-transformed input. The optional joint operator concatenates their frequency-domain weight maps along output channels and computes one FFT of that shared input; each branch then proceeds independently. This sharing is only valid before the branch states diverge.

The graph algorithm leaves `LeakyReLU`, residual additions, and the parallel branch average *where they are*. It must not conflate nonlinearities or reorder floating-point residual accumulation. For `ResBlock1`, each of the three branches has three `(dilated Conv1d, Conv1d)` residual pairs.

## Why it may help

The direct dense operation costs approximately `2*T*K*C^2` FLOPs per ungrouped square convolution. A full-spectrum dense complex product costs `8*ceil(T/M)*(N/2+1)*C^2` FLOPs, plus input/output FFT work. Consequently the candidate does not require sparse or low-rank weights. The cost model uses an explicitly hypothetical 16 MiB per-filter spectrum budget and chooses direct vs spectral separately for each convolution. The model is a filter, not evidence of GPU speed.

However, a frequency-domain filter occupies `8*(N/2+1)*C^2` bytes in complex64, much larger than the original dense short kernel. It may exceed L2 and become bandwidth-bound, while small complex batched matrix multiplications may under-utilize tensor cores. Another issue is FFT input/output transform costs and the nonlinearities that force return to the time domain. This experiment is **not** a claim that FFT must beat cuDNN or a new algorithmic breakthrough.

## Validated locally

`python -m unittest -v test_reference.py test_torch.py`

The NumPy reference verifies single convolutions and complete three-branch nonlinear ResBlocks at float64. Independently, Torch's FP32 Conv1d is checked against the vectorized real-FFT overlap-save implementation, with precomputed and uncached filter spectra, including odd channels and groups. The Torch tests also prove equivalence of the full three-branch nonlinear ResBlock and of the shared-input joint spectral operator. These tests validate the math for the supported subgraph, **not** a full NSF generator or actual `.pth` voice model.

`python cost_model.py --output-json cost_model_40k.json`

On the 40k configuration at T=128, analytical dense ResBlock count is 56.812 billion MAC. The cost-selection model yields 0.395 of direct arithmetic FLOPs, ignoring actual GPU performance. No GPU or audio tests have yet been performed.

## Windows CUDA probe

Use the existing torch CUDA Python interpreter:

`D:\Projects\tts-with-rvc\.venv\Scripts\python.exe benchmark_cuda.py --cases stage1_k11_d5 stage2_k11_d5 stage3_k3_d1 --joint --repetitions 8 --output stage114_cuda_results.json`

Run from the directory containing this file. Alternatively, in PowerShell execute `./Run-Stage114.ps1` with `-PythonExe` to override your interpreter. The CUDA experiment intentionally compares **cuDNN direct Conv1d** against a **PyTorch-eager FFT proof of concept**, not custom optimized CUDA. A slowdown is informative about costs but does not reject a custom kernel; do not equate eager overhead with the asymptotic floor. Both measurements use device events, and the spectra are prepacked once.

## Stop conditions and next algorithm iteration

1. If full FP32 CUDA parity fails, inspect phase offsets, FFT precision and edge behavior before optimizing.
2. If spectral eager is slow, inspect its subcomponent traces (unfold, FFT, complex reduction, inverse FFT) before writing CubeCL kernels.
3. If spectra repeatedly spill out of cache or frequency GEMM is underutilized, use direct Tensor-Core Conv1d for that stage; do not force FFT everywhere.
4. For an actual `.pth`, verify weight_norm removal and test **all 18 convolutions per stage**, residual branch state and final WAV, comparing against native PyTorch GeneratorNSF.
5. Only implement a Rust/CubeCL backend after an instrumented GPU experiment and accepted numerical envelope. Validate GPU kernel runtime/JIT separately; cargo check alone cannot prove it.

## Relationship to Stage 113

Stage113 phase-indexed exactness tests and phase-SVD weight inspection remain a separate experimental route. The Stage113 synthetic low-rank evidence is not proof that a trained RVC voice compresses. Stage114 makes no such assumption.
