"""Vectorized PyTorch overlap-save probe, not an optimized CUDA implementation."""

import math

import torch
import torch.nn.functional as F


def spectral_filter(weight: torch.Tensor, dilation: int, fft_size: int) -> torch.Tensor:
    cout, cin, kernel = weight.shape
    radius = (kernel - 1) * dilation
    if radius % 2 or fft_size <= radius or fft_size & (fft_size - 1):
        raise ValueError("expected odd kernel, centered padding and power-of-two FFT larger than radius")
    pad = radius // 2
    impulse = weight.new_zeros((fft_size, cout, cin))
    for tap in range(kernel):
        impulse[(pad - tap * dilation) % fft_size] = weight[:, :, tap]
    return torch.fft.rfft(impulse, dim=0)


def overlap_save_conv1d(x: torch.Tensor, weight: torch.Tensor, bias: torch.Tensor | None,
                        dilation: int, fft_size: int, groups: int = 1,
                        precomputed_filter: torch.Tensor | None = None) -> torch.Tensor:
    """Execute centered Conv1d with shape [batch, channels, time]."""
    batch, ci, length = x.shape
    cout, group_ci, kernel = weight.shape
    assert ci == group_ci * groups and cout % groups == 0
    radius = (kernel - 1) * dilation
    pad = radius // 2
    valid = fft_size - radius
    if valid <= 0 or radius % 2 or fft_size & (fft_size - 1):
        raise ValueError("invalid length or centered-padding contract")
    count = math.ceil(length / valid)
    right = max(0, count * valid + radius - pad - length)
    padded = F.pad(x, (pad, right))
    frames = padded.unfold(-1, fft_size, valid)
    frequency_input = torch.fft.rfft(frames, dim=-1).permute(0, 2, 1, 3)
    spectrum = precomputed_filter if precomputed_filter is not None else spectral_filter(weight, dilation, fft_size)
    output_groups = cout // groups
    frequency_output = torch.einsum(
        "bngcf,gocf->bngof",
        frequency_input.reshape(batch, count, groups, group_ci, fft_size // 2 + 1),
        spectrum.reshape(fft_size // 2 + 1, groups, output_groups, group_ci).permute(1, 2, 3, 0),
    )
    flattened = frequency_output.reshape(batch, count, cout, fft_size // 2 + 1)
    windows = torch.fft.irfft(flattened, n=fft_size, dim=-1)
    return windows[..., pad:pad + valid].permute(0, 2, 1, 3).reshape(batch, cout, count * valid)[..., :length] + (
        bias.reshape(1, cout, 1) if bias is not None else 0
    )


def direct_conv1d(x: torch.Tensor, weight: torch.Tensor, bias: torch.Tensor | None,
                  dilation: int, groups: int = 1) -> torch.Tensor:
    return F.conv1d(x, weight, bias, padding=(weight.shape[-1] - 1) * dilation // 2,
                    dilation=dilation, groups=groups)


def joint_first_branch_convs(x: torch.Tensor, weights: list[torch.Tensor], biases: list[torch.Tensor],
                             dilations: list[int], fft_size: int,
                             spectra: list[torch.Tensor] | None = None) -> list[torch.Tensor]:
    """Evaluate shared-input first residual convolutions as one spectral linear map."""
    if not weights or len(weights) != len(biases) or len(weights) != len(dilations):
        raise ValueError("weights/biases/dilations must be nonempty and aligned")
    batch, cin, length = x.shape
    if any(w.shape[1] != cin for w in weights):
        raise ValueError("this exact joint operator requires non-grouped common input channels")
    radius = max((w.shape[-1] - 1) * d for w, d in zip(weights, dilations))
    if radius % 2 or fft_size <= radius or fft_size & (fft_size - 1):
        raise ValueError("invalid FFT or noncentered convolution shape")
    if any((w.shape[-1] - 1) * d % 2 for w, d in zip(weights, dilations)):
        raise ValueError("all convolutions must have centered integer padding")
    valid, padding = fft_size - radius, radius // 2
    count = math.ceil(length / valid)
    right = max(0, count * valid + radius - padding - length)
    frames = F.pad(x, (padding, right)).unfold(-1, fft_size, valid)
    xfreq = torch.fft.rfft(frames, dim=-1).permute(0, 2, 3, 1)
    if spectra is None:
        spectra = [spectral_filter(w, d, fft_size) for w, d in zip(weights, dilations)]
    joined_spectrum = torch.cat(spectra, dim=1)
    mixed = torch.einsum("bnfc,foc->bnof", xfreq, joined_spectrum)
    time = torch.fft.irfft(mixed, n=fft_size, dim=-1)
    flattened = time[..., padding:padding + valid].permute(0, 2, 1, 3).reshape(batch, -1, count * valid)[..., :length]
    chunks = flattened.split([w.shape[0] for w in weights], dim=1)
    return [chunk + bias.reshape(1, -1, 1) for chunk, bias in zip(chunks, biases)]
