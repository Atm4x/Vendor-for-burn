"""RTX A/B probe: cuDNN direct Conv1d against eager spectral graph implementation."""

import argparse
import json
import statistics
from pathlib import Path

import torch

from torch_candidate import direct_conv1d, overlap_save_conv1d, spectral_filter, joint_first_branch_convs


CASES = {
    "stage0_k11_d5": {"channels": 256, "length": 1280, "kernel": 11, "dilation": 5, "fft_size": 64},
    "stage1_k11_d5": {"channels": 128, "length": 12800, "kernel": 11, "dilation": 5, "fft_size": 128},
    "stage1_k7_d3": {"channels": 128, "length": 12800, "kernel": 7, "dilation": 3, "fft_size": 128},
    "stage2_k11_d5": {"channels": 64, "length": 25600, "kernel": 11, "dilation": 5, "fft_size": 128},
    "stage3_k11_d5": {"channels": 32, "length": 51200, "kernel": 11, "dilation": 5, "fft_size": 128},
    "stage3_k3_d1": {"channels": 32, "length": 51200, "kernel": 3, "dilation": 1, "fft_size": 64},
}


def timing(fn, repetitions: int) -> dict:
    times = []
    for _ in range(3):
        fn()
    torch.cuda.synchronize()
    for _ in range(repetitions):
        start = torch.cuda.Event(enable_timing=True)
        stop = torch.cuda.Event(enable_timing=True)
        start.record()
        fn()
        stop.record()
        stop.synchronize()
        times.append(start.elapsed_time(stop))
    return {"median_ms": statistics.median(times), "samples_ms": times}


def run_case(name: str, repetitions: int, nfft_override: int | None = None) -> dict:
    params = CASES[name].copy()
    if nfft_override:
        params["fft_size"] = nfft_override
    c, t, k, d, n = (params[key] for key in ["channels", "length", "kernel", "dilation", "fft_size"])
    torch.manual_seed(114)
    x = torch.randn(1, c, t, device="cuda", dtype=torch.float32) * 0.1
    w = torch.randn(c, c, k, device="cuda", dtype=torch.float32) * 0.01
    b = torch.randn(c, device="cuda", dtype=torch.float32) * 0.01
    freq_filter = spectral_filter(w, d, n)
    direct_fn = lambda: direct_conv1d(x, w, b, d)
    spectral_fn = lambda: overlap_save_conv1d(x, w, b, d, n, precomputed_filter=freq_filter)
    reference = direct_fn()
    candidate = spectral_fn()
    torch.cuda.synchronize()
    delta = reference - candidate
    snr = 20 * torch.log10(torch.linalg.vector_norm(reference) / torch.linalg.vector_norm(delta).clamp_min(1e-30))
    tolerance = 1e-4 + 1e-4 * reference.abs()
    result = {
        "case": name, "params": params, "device": torch.cuda.get_device_name(),
        "torch": torch.__version__, "max_abs": float(delta.abs().max().item()),
        "snr_db": float(snr.item()), "parity_atol_rtol_1e4": bool((delta.abs() <= tolerance).all().item()),
        "direct_cudnn": timing(direct_fn, repetitions),
        "spectral_eager": timing(spectral_fn, repetitions),
        "notes": "Precomputed filter FFT is excluded from both calls. Spectral PyTorch eager is not optimized custom CUDA.",
    }
    result["spectral_over_direct_median"] = result["spectral_eager"]["median_ms"] / result["direct_cudnn"]["median_ms"]
    return result


def run_joint(repetitions: int) -> dict:
    channels, length, fft_size = 128, 12800, 64
    torch.manual_seed(1141)
    x = torch.nn.functional.leaky_relu(torch.randn(1, channels, length, device="cuda") * 0.1, 0.1)
    ks, ds = [3, 7, 11], [1, 1, 1]
    weights = [torch.randn(channels, channels, k, device="cuda") * 0.01 for k in ks]
    biases = [torch.randn(channels, device="cuda") * 0.01 for _ in ks]
    prepacked = [spectral_filter(w, d, fft_size) for w, d in zip(weights, ds)]
    direct_fn = lambda: [direct_conv1d(x, w, b, d) for w, b, d in zip(weights, biases, ds)]
    spectral_fn = lambda: joint_first_branch_convs(x, weights, biases, ds, fft_size, prepacked)
    refs, actuals = direct_fn(), spectral_fn()
    torch.cuda.synchronize()
    max_abs = max(float((ref - actual).abs().max().item()) for ref, actual in zip(refs, actuals))
    accurate = all(bool(torch.all((ref - actual).abs() <= 1e-4 + 1e-4 * ref.abs()).item()) for ref, actual in zip(refs, actuals))
    direct_time = timing(direct_fn, repetitions)
    candidate_time = timing(spectral_fn, repetitions)
    return {"case": "joint_stage1_first_residual_convs", "device": torch.cuda.get_device_name(),
            "channels": channels, "length": length, "fft_size": fft_size,
            "max_abs": max_abs, "parity_atol_rtol_1e4": accurate,
            "direct_cudnn": direct_time, "spectral_eager": candidate_time,
            "spectral_over_direct_median": candidate_time["median_ms"] / direct_time["median_ms"],
            "notes": "The spectral path shares one input FFT across the K3,K7,K11 first-branch convolutions."}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cases", nargs="+", choices=sorted(CASES), default=["stage1_k11_d5", "stage2_k11_d5", "stage3_k3_d1"])
    parser.add_argument("--repetitions", type=int, default=8)
    parser.add_argument("--joint", action="store_true", help="also benchmark one shared-input three-branch spectral operator")
    parser.add_argument("--fft-size", type=int)
    parser.add_argument("--output", type=Path, default=Path("stage114_cuda_results.json"))
    args = parser.parse_args()
    if args.repetitions < 1:
        parser.error("repetitions must be positive")
    if not torch.cuda.is_available():
        parser.error("CUDA is not available in this PyTorch installation")
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False
    results = [run_case(case, args.repetitions, args.fft_size) for case in args.cases]
    if args.joint:
        results.append(run_joint(args.repetitions))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(results, indent=2) + "\n", encoding="utf8")
    for result in results:
        print(f"{result['case']}: parity={result['parity_atol_rtol_1e4']} "
              f"snr={result.get('snr_db', float('nan')):.2f}dB cudnn={result['direct_cudnn']['median_ms']:.4f}ms "
              f"eager_spectral={result['spectral_eager']['median_ms']:.4f}ms "
              f"ratio={result['spectral_over_direct_median']:.3f}")


if __name__ == "__main__":
    main()
