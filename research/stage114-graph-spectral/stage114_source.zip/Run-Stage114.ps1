param(
    [string]$PythonExe = "D:\Projects\tts-with-rvc\.venv\Scripts\python.exe",
    [int]$Repetitions = 8,
    [string]$Output = "stage114_cuda_results.json"
)

$ErrorActionPreference = "Stop"
Push-Location $PSScriptRoot
try {
    & $PythonExe -m unittest -v test_reference.py test_torch.py
    if ($LASTEXITCODE -ne 0) { throw "Stage114 mathematical parity tests failed" }
    & $PythonExe benchmark_cuda.py --cases stage1_k11_d5 stage2_k11_d5 stage3_k3_d1 --repetitions $Repetitions --joint --output $Output
    if ($LASTEXITCODE -ne 0) { throw "Stage114 CUDA A/B failed" }
} finally {
    Pop-Location
}
