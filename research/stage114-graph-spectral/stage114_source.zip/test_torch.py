"""Independent PyTorch Conv1d parity including grouped and odd-channel cases."""

import unittest

import torch

from torch_candidate import direct_conv1d, overlap_save_conv1d, spectral_filter, joint_first_branch_convs


class TorchCandidateTest(unittest.TestCase):

    def test_joint_first_conv_for_three_branches(self):
        torch.manual_seed(220114)
        for length, channels, fft_size in [(11, 3, 32), (111, 7, 64), (310, 8, 128)]:
            with self.subTest(length=length, channels=channels):
                x = torch.randn(2, channels, length)
                kernels, dilations = [3, 7, 11], [1, 1, 1]
                weights = [torch.randn(channels, channels, k) * 0.04 for k in kernels]
                biases = [torch.randn(channels) * 0.02 for _ in kernels]
                reference = [direct_conv1d(x, w, b, d) for w, b, d in zip(weights, biases, dilations)]
                joined = joint_first_branch_convs(x, weights, biases, dilations, fft_size)
                prepacked = [spectral_filter(w, d, fft_size) for w, d in zip(weights, dilations)]
                joined_prepacked = joint_first_branch_convs(x, weights, biases, dilations, fft_size, prepacked)
                for candidate in [joined, joined_prepacked]:
                    for expected, actual in zip(reference, candidate):
                        torch.testing.assert_close(expected, actual, rtol=5e-5, atol=5e-6)

    def test_complete_three_branch_resblock_against_torch_f32(self):
        torch.manual_seed(1114)
        for channels, groups, length in [(3, 1, 17), (4, 2, 51)]:
            with self.subTest(channels=channels, groups=groups, length=length):
                x = torch.randn(1, channels, length, dtype=torch.float32) * 0.2
                branches = []
                for kernel in [3, 7, 11]:
                    pairs = []
                    for dilation in [1, 3, 5]:
                        a = (torch.randn(channels, channels // groups, kernel) * 0.025,
                             torch.randn(channels) * 0.01, dilation)
                        b = (torch.randn(channels, channels // groups, kernel) * 0.025,
                             torch.randn(channels) * 0.01, 1)
                        pairs.append((a, b))
                    branches.append(pairs)
                outputs = []
                for spectral in [False, True]:
                    total = torch.zeros_like(x)
                    for pairs in branches:
                        state = x
                        for a, b in pairs:
                            def apply_conv(v, params):
                                w, bias, d = params
                                if spectral:
                                    return overlap_save_conv1d(v, w, bias, d, 128, groups)
                                return direct_conv1d(v, w, bias, d, groups)
                            inner = apply_conv(torch.nn.functional.leaky_relu(state, 0.1), a)
                            update = apply_conv(torch.nn.functional.leaky_relu(inner, 0.1), b)
                            state = state + update
                        total = total + state
                    outputs.append(total / 3)
                torch.testing.assert_close(outputs[0], outputs[1], rtol=5e-5, atol=5e-6)

    def test_against_torch_conv1d_f32(self):
        torch.manual_seed(114)
        for length, cin, cout, groups, kernel, dilation, nfft in [
            (17, 3, 5, 1, 3, 1, 16), (89, 8, 12, 2, 7, 3, 64),
            (100, 9, 9, 3, 11, 5, 128), (2, 2, 4, 1, 7, 5, 64),
            (97, 7, 11, 1, 11, 1, 64), (130, 4, 6, 2, 3, 3, 32),
        ]:
            with self.subTest(length=length, cin=cin, cout=cout, groups=groups, kernel=kernel, dilation=dilation):
                x = torch.randn(2, cin, length, dtype=torch.float32)
                w = torch.randn(cout, cin // groups, kernel, dtype=torch.float32) * 0.05
                b = torch.randn(cout, dtype=torch.float32) * 0.03
                ref = direct_conv1d(x, w, b, dilation, groups)
                prepacked = spectral_filter(w, dilation, nfft)
                for h in [None, prepacked]:
                    actual = overlap_save_conv1d(x, w, b, dilation, nfft, groups, h)
                    torch.testing.assert_close(ref, actual, rtol=5e-5, atol=5e-6)


if __name__ == "__main__":
    unittest.main()
