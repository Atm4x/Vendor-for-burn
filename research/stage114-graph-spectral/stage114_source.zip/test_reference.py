"""Numerical regression of graph-preserving spectral residual execution."""

import unittest

import numpy as np

from reference import ConvSpec, SpectralConv, decoder_resblocks, direct, generated_block


class SpectralReferenceTests(unittest.TestCase):
    def test_single_convolution_any_kernel_dilation_groups(self):
        rng = np.random.default_rng(114)
        for length, ci, co, groups, kernel, dilation, fft_size in [
            (17, 3, 5, 1, 3, 1, 16),
            (89, 8, 12, 2, 7, 3, 64),
            (100, 9, 9, 3, 11, 5, 128),
            (31, 13, 7, 1, 3, 5, 32),
            (97, 7, 11, 1, 11, 1, 64),
            (2, 2, 4, 1, 7, 5, 64),
            (130, 4, 6, 2, 3, 3, 32),
        ]:
            with self.subTest(length=length, channels=(ci, co), groups=groups, kernel=kernel, dilation=dilation):
                weight = rng.normal(0, 0.08, (co, ci // groups, kernel))
                bias = rng.normal(0, 0.1, co)
                x = rng.normal(0, 0.2, (length, ci))
                spec = ConvSpec(weight, bias, dilation, groups)
                reference = direct(x, spec)
                candidate = SpectralConv(spec, fft_size)(x)
                np.testing.assert_allclose(reference, candidate, rtol=1e-11, atol=1e-11)

    def test_full_three_branch_resblock1_with_nonlinearities(self):
        rng = np.random.default_rng(2205)
        for length, channels, groups in [(19, 4, 1), (70, 4, 2), (11, 3, 1)]:
            with self.subTest(length=length, channels=channels, groups=groups):
                block = generated_block(channels, 2211 + length, groups)
                x = rng.normal(0, 0.3, (length, channels))
                fft_sizes = [[(128, 64), (128, 128), (128, 128)] for _ in range(3)]
                baseline = decoder_resblocks(x, block, False)
                candidate = decoder_resblocks(x, block, True, fft_sizes)
                np.testing.assert_allclose(baseline, candidate, rtol=1e-10, atol=1e-10)

    def test_invalid_fft_size_rejected(self):
        spec = ConvSpec(np.ones((2, 2, 11)), np.zeros(2), 5)
        for size in [16, 32, 48]:
            with self.assertRaises(ValueError):
                SpectralConv(spec, size)


if __name__ == "__main__":
    unittest.main()
