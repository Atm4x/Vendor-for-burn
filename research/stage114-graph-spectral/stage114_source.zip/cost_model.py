"""Arithmetic and transformed-weight footprint model for the RVC v2 40 kHz ResBlocks."""

import argparse
import json
import math
from pathlib import Path


def estimate(length: int, channels: int, kernel: int, dilation: int, nfft: int) -> dict:
    receptive_radius = (kernel - 1) * dilation
    if nfft <= receptive_radius:
        raise ValueError("FFT length must exceed the receptive radius")
    valid = nfft - receptive_radius
    blocks = math.ceil(length / valid)
    frequencies = nfft // 2 + 1
    dense_mac = length * kernel * channels * channels
    dense_flops = 2 * dense_mac
    spectral_gemm_flops = 8 * blocks * frequencies * channels * channels
    spectral_fft_flops = 5 * blocks * nfft * math.log2(nfft) * channels
    spectrum_bytes = frequencies * channels * channels * 8
    temporal_complex_bytes = blocks * frequencies * channels * 8
    return {
        "nfft": nfft,
        "valid_per_block": valid,
        "blocks": blocks,
        "dense_mac": dense_mac,
        "dense_flops": dense_flops,
        "spectral_gemm_flops": spectral_gemm_flops,
        "spectral_fft_flops_approx": round(spectral_fft_flops),
        "spectral_vs_dense_flops_approx": (spectral_gemm_flops + spectral_fft_flops) / dense_flops,
        "spectral_filter_mib": spectrum_bytes / 1048576,
        "spectral_input_mib": temporal_complex_bytes / 1048576,
    }


def stages_40k() -> list[dict]:
    length = 128
    cin = 512
    output = []
    for i, (stride, cout) in enumerate([(10, 256), (10, 128), (2, 64), (2, 32)]):
        length *= stride
        output.append({"stage": i, "length": length, "input_channels": cin, "output_channels": cout, "stride": stride})
        cin = cout
    return output


def build_budget_report(budget_mib: float) -> dict:
    rows = []
    direct_sum, chosen_sum = 0, 0.0
    for stage in stages_40k():
        length, channels = stage["length"], stage["output_channels"]
        for kernel in [3, 7, 11]:
            for dilation in [1, 3, 5]:
                for position, current_dilation in [("conv1", dilation), ("conv2", 1)]:
                    options = [estimate(length, channels, kernel, current_dilation, n)
                               for n in [32, 64, 128, 256, 512, 1024]
                               if n > (kernel - 1) * current_dilation]
                    valid = [v for v in options if v["spectral_filter_mib"] <= budget_mib]
                    best = min(valid, key=lambda v: v["spectral_vs_dense_flops_approx"]) if valid else None
                    dense = options[0]["dense_flops"]
                    ratio = best["spectral_vs_dense_flops_approx"] if best else float("inf")
                    selection = "spectral" if ratio < 1 else "direct"
                    row = {**stage, "kernel": kernel, "dilation": current_dilation,
                           "position": position, "dense_mac": options[0]["dense_mac"],
                           "chosen": selection, "best_fft": best if selection == "spectral" else None,
                           "chosen_over_dense_flops": min(1.0, ratio)}
                    rows.append(row)
                    direct_sum += dense
                    chosen_sum += dense * min(1.0, ratio)
    return {
        "scope": "GeneratorNSF ResBlock1 only; 40k, T_in=128, C=[256,128,64,32]",
        "heuristic_spectrum_size_budget_mib": budget_mib,
        "not_included": ["CUDA implementation", "occupancy", "real memory bandwidth", "FFT launch latency",
                         "frequency-GEMM efficiency", "filter FFT setup", "f32 roundoff and waveform parity"],
        "dense_total_mac": direct_sum // 2,
        "direct_total_flops": direct_sum,
        "selected_analytic_flops_approx": round(chosen_sum),
        "optimistic_analytic_flop_ratio": chosen_sum / direct_sum,
        "rows": rows,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--spectrum-budget-mib", type=float, default=16)
    parser.add_argument("--output-json", type=Path)
    args = parser.parse_args()
    if args.spectrum_budget_mib <= 0:
        parser.error("budget must be positive")
    result = build_budget_report(args.spectrum_budget_mib)
    data = json.dumps(result, ensure_ascii=False, indent=2)
    if args.output_json:
        args.output_json.parent.mkdir(parents=True, exist_ok=True)
        args.output_json.write_text(data + "\n", encoding="utf8")
    print(f"ResBlock dense: {result['dense_total_mac']/1e9:.3f} G MAC")
    print(f"Optimistic math FLOP ratio: {result['optimistic_analytic_flop_ratio']:.4f}")
    for stage in stages_40k():
        rows = [r for r in result["rows"] if r["stage"] == stage["stage"]]
        total = sum(r["dense_mac"] for r in rows)
        selected = sum(r["dense_mac"] * r["chosen_over_dense_flops"] for r in rows)
        spectral_count = sum(r["chosen"] == "spectral" for r in rows)
        print(f"stage={stage['stage']} C={stage['output_channels']} T={stage['length']} "
              f"spectral_layers={spectral_count}/18 analytic_ratio={selected/total:.4f}")


if __name__ == "__main__":
    main()
