"""Direct and overlap-save spectral execution of dense dilated residual convolutions."""

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class ConvSpec:
    weight: np.ndarray
    bias: np.ndarray
    dilation: int = 1
    groups: int = 1

    @property
    def radius(self) -> int:
        return (self.weight.shape[-1] - 1) * self.dilation

    @property
    def padding(self) -> int:
        assert self.radius % 2 == 0
        return self.radius // 2


def direct(x: np.ndarray, spec: ConvSpec) -> np.ndarray:
    t, ci = x.shape
    co, group_ci, k = spec.weight.shape
    assert spec.groups > 0 and ci == group_ci * spec.groups and co % spec.groups == 0
    result = np.broadcast_to(spec.bias[None, :], (t, co)).astype(np.float64).copy()
    out_per_group = co // spec.groups
    for j in range(k):
        displacement = j * spec.dilation - spec.padding
        lower, upper = max(0, -displacement), min(t, t - displacement)
        if upper <= lower:
            continue
        for group in range(spec.groups):
            xs = x[lower + displacement:upper + displacement, group * group_ci:(group + 1) * group_ci]
            w = spec.weight[group * out_per_group:(group + 1) * out_per_group, :, j]
            result[lower:upper, group * out_per_group:(group + 1) * out_per_group] += xs @ w.T
    return result


class SpectralConv:
    """One-sided overlap-save FFT with precomputed convolution spectra."""

    def __init__(self, spec: ConvSpec, fft_size: int):
        self.spec = spec
        self.fft_size = fft_size
        self.valid = fft_size - spec.radius
        if self.valid <= 0 or fft_size & (fft_size - 1):
            raise ValueError("fft_size must be a power of two larger than the receptive radius")
        cout, ci_per_group, kernel = spec.weight.shape
        impulses = np.zeros((fft_size, cout, ci_per_group), dtype=np.float64)
        for tap in range(kernel):
            offset = (spec.padding - tap * spec.dilation) % fft_size
            impulses[offset] += spec.weight[..., tap]
        self.filters = np.fft.rfft(impulses, axis=0)

    def __call__(self, x: np.ndarray) -> np.ndarray:
        t, ci = x.shape
        cout, ci_per_group, _ = self.spec.weight.shape
        assert ci == ci_per_group * self.spec.groups and cout % self.spec.groups == 0
        result = np.empty((t, cout), dtype=np.float64)
        cout_group = cout // self.spec.groups
        p = self.spec.padding
        for start in range(0, t, self.valid):
            window = np.zeros((self.fft_size, ci), dtype=np.float64)
            first = start - p
            lower, upper = max(0, first), min(t, first + self.fft_size)
            if upper > lower:
                window[lower - first:upper - first] = x[lower:upper]
            spectrum = np.fft.rfft(window, axis=0)
            output_spectrum = np.empty((self.fft_size // 2 + 1, cout), dtype=np.complex128)
            for group in range(self.spec.groups):
                output_spectrum[:, group * cout_group:(group + 1) * cout_group] = np.einsum(
                    "foc,fc->fo",
                    self.filters[:, group * cout_group:(group + 1) * cout_group],
                    spectrum[:, group * ci_per_group:(group + 1) * ci_per_group],
                    optimize=True,
                )
            expanded = np.fft.irfft(output_spectrum, n=self.fft_size, axis=0)
            size = min(self.valid, t - start)
            result[start:start + size] = expanded[p:p + size] + self.spec.bias[None, :]
        return result


def leaky(x: np.ndarray) -> np.ndarray:
    return np.where(x >= 0, x, x * 0.1)


def branch(x: np.ndarray, pairs: list[tuple[ConvSpec, ConvSpec]], spectral: bool, fft_sizes: list[tuple[int, int]] | None = None) -> np.ndarray:
    state = x
    for i, (a, b) in enumerate(pairs):
        if spectral:
            assert fft_sizes is not None
            aop = SpectralConv(a, fft_sizes[i][0])
            bop = SpectralConv(b, fft_sizes[i][1])
            branch_result = bop(leaky(aop(leaky(state))))
        else:
            branch_result = direct(leaky(direct(leaky(state), a)), b)
        state = state + branch_result
    return state


def decoder_resblocks(x: np.ndarray, branches: list[list[tuple[ConvSpec, ConvSpec]]], spectral: bool, fft_sizes: list[list[tuple[int, int]]] | None = None) -> np.ndarray:
    output = np.zeros_like(x, dtype=np.float64)
    for index, pairs in enumerate(branches):
        selected = fft_sizes[index] if fft_sizes is not None else None
        output += branch(x, pairs, spectral, selected)
    return output / len(branches)


def generated_block(channels: int, seed: int, groups: int = 1) -> list[list[tuple[ConvSpec, ConvSpec]]]:
    rng = np.random.default_rng(seed)
    branches = []
    for kernel in [3, 7, 11]:
        pairs = []
        for dilation in [1, 3, 5]:
            weight_a = rng.normal(0, 0.008, (channels, channels // groups, kernel))
            weight_b = rng.normal(0, 0.008, (channels, channels // groups, kernel))
            ba = rng.normal(0, 0.004, channels)
            bb = rng.normal(0, 0.004, channels)
            pairs.append((ConvSpec(weight_a, ba, dilation, groups), ConvSpec(weight_b, bb, 1, groups)))
        branches.append(pairs)
    return branches
